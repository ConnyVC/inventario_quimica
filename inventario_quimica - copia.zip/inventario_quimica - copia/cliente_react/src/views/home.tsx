import { Link, useLoaderData } from 'react-router-dom'
import { getReactivos } from '../services/ReactivoService'
import type { Reactivo } from '../types/reactivo'
import ReactivoFila from '../components/ReactivoFila'

// Loader que React Router ejecuta antes de renderizar la página
export async function loader() {
  const reactivos = await getReactivos()
  return reactivos
}

export default function Home() {
  // Hook para consumir los datos precargados por el loader
  const reactivos = useLoaderData() as Reactivo[]

  return (
    <>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h2>Inventario de Reactivos</h2>
        <Link to="/reactivos/crear" className="btn btn-primary">
          Nuevo Reactivo
        </Link>
      </div>

      <div className="card">
        <div className="card-body">
          <table className="table table-hover">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nombre Químico</th>
                <th>Fórmula</th>
                <th>Stock</th>
                <th>P. Reorden</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {reactivos.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center">No hay reactivos registrados</td>
                </tr>
              ) : (
                reactivos.map((reactivo) => (
                  <ReactivoFila key={reactivo.idReactivo} reactivo={reactivo} />
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  )
}