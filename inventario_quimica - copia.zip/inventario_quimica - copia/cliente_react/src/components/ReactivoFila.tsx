import { useNavigate, Form, redirect, type ActionFunctionArgs } from 'react-router-dom'
import { reactivoBorrar } from '../services/ReactivoService'
import type { Reactivo } from '../types/reactivo'

type ReactivoFilaProps = {
  reactivo: Reactivo
}

// Action que procesa el borrado
export async function action({ params }: ActionFunctionArgs) {
  if (params.id !== undefined) {
    const respuesta = await reactivoBorrar(Number(params.id))
    if (!respuesta.success) {
      console.error(respuesta.error)
    }
  }
  return redirect('/')
}

export default function ReactivoFila({ reactivo }: ReactivoFilaProps) {
  const navigate = useNavigate()

  return (
    <tr>
      <td>{reactivo.idReactivo}</td>
      <td className="fw-bold">{reactivo.nombreQuimico}</td>
      <td>{reactivo.formulaQuimica || '—'}</td>
      <td>
        <span className={Number(reactivo.cantidadDisponible) <= Number(reactivo.puntoReordenMinimo) ? 'text-danger fw-bold' : ''}>
          {reactivo.cantidadDisponible} {reactivo.unidadMedida}
        </span>
      </td>
      <td>
        {reactivo.puntoReordenMinimo} {reactivo.unidadMedida}
      </td>
      <td>
        <div className="d-flex gap-2">
          {/* Botón Editar */}
          <button
            type="button"
            className="btn btn-sm btn-info text-white"
            onClick={() => navigate(`/reactivos/${reactivo.idReactivo}/editar`)}
          >
            Editar
          </button>

          {/* Formulario y Botón Eliminar */}
          <Form
            method="POST"
            action={`/reactivos/${reactivo.idReactivo}/eliminar`}
            onSubmit={(e) => {
              if (!confirm('¿Deseas eliminar este reactivo?')) {
                e.preventDefault()
              }
            }}
          >
            <button
              type="submit"
              className="btn btn-sm btn-danger"
            >
              Eliminar
            </button>
          </Form>
        </div>
      </td>
    </tr>
  )
}