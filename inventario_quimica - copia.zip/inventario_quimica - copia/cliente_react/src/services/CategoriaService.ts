import axiosInstance from './axiosInstance'
import { safeParse } from 'valibot'
import { CategoriasSchema, type Categoria } from '../types/categoria'

export async function getCategorias(): Promise<Categoria[]> {
  try {
    const { data } = await axiosInstance.get('/categorias')
    const datosArray = Array.isArray(data) ? data : data.data || []
    const resultado = safeParse(CategoriasSchema, datosArray)

    if (resultado.success) {
      return resultado.output
    } else {
      console.error('Error al validar categorias:', resultado.issues)
      return []
    }
  } catch (error) {
    console.error('Error al obtener categorias:', error)
    return []
  }
}