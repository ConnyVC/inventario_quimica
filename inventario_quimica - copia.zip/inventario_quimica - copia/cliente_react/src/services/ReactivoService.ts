import axiosInstance from './axiosInstance'
import { safeParse } from 'valibot'
import {
  ReactivoFormSchema,
  ReactivosSchema,
  type ReactivoFormData,
  type Reactivo
} from '../types/reactivo'

// Obtener Reactivos (GET)
export async function getReactivos(): Promise<Reactivo[]> {
  try {
    // Como axiosInstance ya tiene la baseURL con /api, solo pides '/reactivos'
    const { data } = await axiosInstance.get('/reactivos')
    
    console.log('Datos recibidos de la API:', data)

    // Maneja si la API devuelve el arreglo directo o dentro de { data: [...] }
    const datosArray = Array.isArray(data) ? data : data.data || []
    const resultado = safeParse(ReactivosSchema, datosArray)

    if (resultado.success) {
      return resultado.output
    } else {
      console.error('Error de validación en Valibot:', resultado.issues)
      return []
    }
  } catch (error) {
    console.error('Error en la petición GET:', error)
    return []
  }
}

// Obtener un reactivo por ID (GET)
export async function getReactivoById(id: string | number): Promise<Reactivo | null> {
  try {
    const { data } = await axiosInstance.get(`/reactivos/${id}`)
    // Si la API devuelve { data: {...} } o el objeto directo
    const reactivoData = data.data ? data.data : data
    return reactivoData as Reactivo
  } catch (error) {
    console.error(`Error al obtener el reactivo con ID ${id}:`, error)
    return null
  }
}

// Crear Reactivo (POST)
export async function reactivoCrear(formData: ReactivoFormData) {
  try {
    const resultado = safeParse(ReactivoFormSchema, {
      nombreQuimico: formData.nombreQuimico,
      formulaQuimica: formData.formulaQuimica || '',
      unidadMedida: formData.unidadMedida,
      puntoReordenMinimo: Number(formData.puntoReordenMinimo),
      idCategoria: Number(formData.idCategoria),
      cantidadDisponible: Number(formData.cantidadDisponible)
    })

    if (resultado.success) {
      await axiosInstance.post('/reactivos', resultado.output)
      return { success: true }
    } else {
      return { success: false, error: 'Hay un problema con los datos del formulario.' }
    }
  } catch (error) {
    console.error(error)
    return { success: false, error: 'No se pudo crear el reactivo' }
  }
}

// Editar Reactivo (PUT)
export async function reactivoEditar(formData: ReactivoFormData, reactivoId: number) {
  try {
    const resultado = safeParse(ReactivoFormSchema, {
      nombreQuimico: formData.nombreQuimico,
      formulaQuimica: formData.formulaQuimica || '',
      unidadMedida: formData.unidadMedida,
      puntoReordenMinimo: Number(formData.puntoReordenMinimo),
      idCategoria: Number(formData.idCategoria),
      cantidadDisponible: Number(formData.cantidadDisponible)
    })

    if (resultado.success) {
      await axiosInstance.put(`/reactivos/${reactivoId}`, resultado.output)
      return { success: true }
    } else {
      return { success: false, error: 'Datos no válidos' }
    }
  } catch (error) {
    console.error(error)
    return { success: false, error: 'No se pudo editar el reactivo' }
  }
}

// Eliminar Reactivo (DELETE)
export async function reactivoBorrar(reactivoId: number) {
  try {
    await axiosInstance.delete(`/reactivos/${reactivoId}`)
    return { success: true }
  } catch (error) {
    console.error(error)
    return { success: false, error: 'No se pudo eliminar el reactivo' }
  }
}

