import { object, string, number, array, union, optional, nullable, type InferOutput } from 'valibot'

const NumberOrString = union([number(), string()])

export const CategoriaSchema = object({
  id_categoria: optional(NumberOrString),
  idCategoria: optional(NumberOrString),
  nombre_categoria: optional(string()),
  nombreCategoria: optional(string()),
  pictograma: optional(nullable(string())),
  descripcion: optional(nullable(string()))
})

export const CategoriasSchema = array(CategoriaSchema)

export type Categoria = InferOutput<typeof CategoriaSchema>