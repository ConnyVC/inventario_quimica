// 1. Control de Autenticación y Rol
const userRole = localStorage.getItem('user_role') || 'admin';
document.body.classList.add(`role-${userRole}`);

const roleBadge = document.getElementById('roleBadge');
if (roleBadge) {
  roleBadge.textContent = userRole === 'admin' ? 'Perfil: Administrador' : 'Perfil: Docente (Solo Lectura)';
  if (userRole !== 'admin') roleBadge.classList.replace('bg-secondary', 'bg-info');
}

function cerrarSesion() {
  localStorage.removeItem('user_role');
  window.location.href = 'login.html';
}

// 2. Datos Semilla (Basados en el inventario real de tu informe)
let reactivos = [
  { id: 1, nombre: 'Cloruro de Bario 2-hidrato', formula: 'BaCl2*2H2O', unidad: 'g', cantidad: 500, reorden: 100, categoria: 'Mortal' },
  { id: 2, nombre: 'Hidróxido de Bario octahidrato', formula: 'Ba(OH)2*8H2O', unidad: 'g', cantidad: 50, reorden: 100, categoria: 'Corrosivo' },
  { id: 3, nombre: 'Acido Bórico', formula: 'H3BO3', unidad: 'kg', cantidad: 2.5, reorden: 1.0, categoria: 'Nocivo' },
  { id: 4, nombre: 'Sulfato de Bario', formula: 'BaSO4', unidad: 'kg', cantidad: 5, reorden: 2.0, categoria: 'Atención' }
];

// 3. Renderizado de la tabla y contadores
function renderizarTabla() {
  const tbody = document.getElementById('tablaReactivosBody');
  const search = document.getElementById('searchInput').value.toLowerCase();
  const filtroCat = document.getElementById('filtroPeligro').value;
  
  tbody.innerHTML = '';
  let stockCriticoCount = 0;

  const filtrados = reactivos.filter(item => {
    const coincideTexto = item.nombre.toLowerCase().includes(search) || item.formula.toLowerCase().includes(search);
    const coincidePeligro = !filtroCat || item.categoria === filtroCat;
    return coincideTexto && coincidePeligro;
  });

  filtrados.forEach(r => {
    const esCritico = r.cantidad <= r.reorden;
    if (esCritico) stockCriticoCount++;

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="fw-bold text-muted">${r.id}</td>
      <td class="fw-semibold">${r.nombre}</td>
      <td><code>${r.formula}</code></td>
      <td><span class="badge badge-${r.categoria.toLowerCase()}">${r.categoria}</span></td>
      <td class="fw-bold">${r.cantidad} ${r.unidad}</td>
      <td>${r.reorden} ${r.unidad}</td>
      <td>
        ${esCritico 
          ? '<span class="badge bg-danger"><i class="bi bi-exclamation-octagon me-1"></i>Bajo Reorden</span>' 
          : '<span class="badge bg-success">Óptimo</span>'}
      </td>
      <td class="text-end admin-only">
        <button class="btn btn-sm btn-outline-danger" onclick="eliminarReactivo(${r.id})">
          <i class="bi bi-trash"></i>
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });

  // Actualizar métricas del dashboard
  document.getElementById('totalReactivosCount').textContent = reactivos.length;
  document.getElementById('stockCriticoCount').textContent = stockCriticoCount;
  document.getElementById('vencimientoCount').textContent = '2'; // Simulación de lotes por vencer

  actualizarSelectDespacho();
}

// 4. Actualizar opciones del modal de despacho
function actualizarSelectDespacho() {
  const select = document.getElementById('despachoReactivoSelect');
  if (!select) return;
  select.innerHTML = reactivos.map(r => `<option value="${r.id}">${r.nombre} (${r.cantidad} ${r.unidad} disp.)</option>`).join('');
}

// 5. Manejo de Formularios
document.getElementById('formNuevoReactivo').addEventListener('submit', (e) => {
  e.preventDefault();
  const nuevo = {
    id: reactivos.length ? Math.max(...reactivos.map(r => r.id)) + 1 : 1,
    nombre: document.getElementById('nombreReactivo').value,
    formula: document.getElementById('formulaReactivo').value,
    unidad: document.getElementById('unidadMedida').value,
    categoria: document.getElementById('categoriaPeligro').value,
    reorden: parseFloat(document.getElementById('puntoReorden').value),
    cantidad: parseFloat(document.getElementById('cantidadInicial').value)
  };

  reactivos.push(nuevo);
  bootstrap.Modal.getInstance(document.getElementById('modalNuevoReactivo')).hide();
  e.target.reset();
  renderizarTabla();

  Swal.fire({
    icon: 'success',
    title: 'Reactivo Creado',
    text: `${nuevo.nombre} se incorporó correctamente al inventario.`
  });
});

document.getElementById('formDespacho').addEventListener('submit', (e) => {
  e.preventDefault();
  const reactivoId = parseInt(document.getElementById('despachoReactivoSelect').value);
  const cantidad = parseFloat(document.getElementById('despachoCantidad').value);
  const reactivo = reactivos.find(r => r.id === reactivoId);

  if (reactivo.cantidad < cantidad) {
    Swal.fire({
      icon: 'error',
      title: 'Stock Insuficiente',
      text: `Solo quedan ${reactivo.cantidad} ${reactivo.unidad} disponibles en bodega.`
    });
    return;
  }

  // Descuento del stock real disponible
  reactivo.cantidad -= cantidad;
  bootstrap.Modal.getInstance(document.getElementById('modalDespacho')).hide();
  e.target.reset();
  renderizarTabla();

  Swal.fire({
    icon: 'success',
    title: 'Despacho Exitoso',
    text: `Se retiraron ${cantidad} ${reactivo.unidad} de ${reactivo.nombre}.`
  });
});

function eliminarReactivo(id) {
  Swal.fire({
    title: '¿Confirmar baja?',
    text: 'Esta acción deshabilitará el reactivo del catálogo maestro.',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    confirmButtonText: 'Sí, eliminar',
    cancelButtonText: 'Cancelar'
  }).then((result) => {
    if (result.isConfirmed) {
      reactivos = reactivos.filter(r => r.id !== id);
      renderizarTabla();
      Swal.fire('Eliminado', 'El reactivo ha sido dado de baja.', 'success');
    }
  });
}

// 6. Escuchadores de eventos de filtro
document.getElementById('searchInput').addEventListener('input', renderizarTabla);
document.getElementById('filtroPeligro').addEventListener('change', renderizarTabla);

// Inicio inicial
renderizarTabla();