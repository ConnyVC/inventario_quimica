import { Request, Response } from 'express'
import MermaAjuste from '../models/MermaAjuste'
import Lote from '../models/Lote'
import Reactivo from '../models/Reactivo'


export const getMermas = async (req: Request, res: Response) => {
  try {
    const mermas = await MermaAjuste.findAll({
      order: [['fechaAjuste', 'DESC']]
    })
    res.json({ data: mermas })
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: 'Error al obtener las mermas y ajustes' })
  }
}

export const createMerma = async (req: Request, res: Response) => {
  try {
    const {
      idLote,
      tipoAjuste,
      motivoAjuste,
      cantidadAfectada,
      observacion
    } = req.body

    const cantidad = Number(cantidadAfectada)
    if (!idLote || cantidad <= 0) {
      return res.status(400).json({ message: 'Lote o cantidad inválida' })
    }

    const lote = await Lote.findByPk(Number(idLote))
    if (!lote) {
      return res.status(404).json({ message: 'El lote seleccionado no existe' })
    }

    const stockLoteActual = Number(lote.stockDisponible ?? 0)
    if (tipoAjuste === 'Salida' && cantidad > stockLoteActual) {
      return res.status(400).json({
        message: `Stock insuficiente en el lote (disponible: ${stockLoteActual})`
      })
    }

    const nuevaMerma = await MermaAjuste.create({
      idLote: Number(idLote),
      tipoAjuste: tipoAjuste || 'Salida',
      motivoAjuste: motivoAjuste || 'Vencimiento',
      fechaAjuste: new Date(),
      cantidadAfectada: cantidad,
      observacion: observacion || '',
      idUsuario: (req as any).usuario?.idUsuario ?? 1
    })

    // 1. Actualizar saldo disponible del lote físico
    const nuevoStockLote =
      tipoAjuste === 'Entrada'
        ? stockLoteActual + cantidad
        : Math.max(0, stockLoteActual - cantidad)

    await lote.update({ stockDisponible: nuevoStockLote })

    // 2. Actualizar stock acumulado del reactivo en tbl_reactivo
    const reactivo = await Reactivo.findByPk(Number(lote.idReactivo))
    if (reactivo) {
      const stockReactivoActual = Number(reactivo.cantidadDisponible ?? 0)
      const nuevoStockReactivo =
        tipoAjuste === 'Entrada'
          ? stockReactivoActual + cantidad
          : Math.max(0, stockReactivoActual - cantidad)

      await reactivo.update({ cantidadDisponible: nuevoStockReactivo })
    }

    res.status(201).json({ data: nuevaMerma })
  } catch (error) {
    console.error('Error al registrar merma:', error)
    res.status(500).json({ message: 'Error al registrar la merma o ajuste' })
  }
}