import { Request, Response } from 'express'
import Movimiento from '../models/Movimiento'
import Consumo from '../models/Consumo'
import Asignatura from '../models/Asignatura'
import Docente from '../models/Docente'
import Lote from '../models/Lote'
import Reactivo from '../models/Reactivo'

export const getAsignaturas = async (req: Request, res: Response) => {
  try {
    const asignaturas = await Asignatura.findAll({
      where: { estado: 1 }
    })
    res.json({ data: asignaturas })
  } catch (error) {
    console.error('Error al obtener asignaturas:', error)
    res.status(500).json({ message: 'Error al obtener las asignaturas' })
  }
}

export const getDocentes = async (req: Request, res: Response) => {
  try {
    const docentes = await Docente.findAll({
      where: { estado: 1 }
    })
    res.json({ data: docentes })
  } catch (error) {
    console.error('Error al obtener docentes:', error)
    res.status(500).json({ message: 'Error al obtener los docentes' })
  }
}

export const getMovimientos = async (req: Request, res: Response) => {
  try {
    const movimientos = await Movimiento.findAll()
    // Ordenar del más reciente al más antiguo en JS para evitar errores de nombres de columna en SQL
    movimientos.sort((a: any, b: any) => Number(b.idMovimiento ?? 0) - Number(a.idMovimiento ?? 0))
    res.json({ data: movimientos })
  } catch (error) {
    console.error('Error al obtener movimientos:', error)
    res.status(500).json({ message: 'Error al obtener la bitácora de movimientos' })
  }
}

export const createMovimiento = async (req: Request, res: Response) => {
  try {
    const {
      idLote,
      tipoMovimiento,
      cantidad,
      idAsignatura,
      idDocente,
      actividadPractica,
      observacion
    } = req.body

    const cant = Number(cantidad)
    const tipo = tipoMovimiento || 'Despacho'

    if (!idLote || cant <= 0) {
      return res.status(400).json({ message: 'Lote o cantidad inválida' })
    }

    const lote = await Lote.findByPk(Number(idLote))
    if (!lote) {
      return res.status(404).json({ message: 'El lote seleccionado no existe' })
    }

    const stockLoteActual = Number(lote.stockDisponible ?? 0)
    if (tipo === 'Despacho' && cant > stockLoteActual) {
      return res.status(400).json({
        message: `Stock insuficiente en el lote (disponible: ${stockLoteActual})`
      })
    }

    // 1. Registrar movimiento principal en tbl_movimiento
    const nuevoMovimiento = await Movimiento.create({
      idLote: Number(idLote),
      tipoMovimiento: tipo,
      fechaMovimiento: new Date(),
      cantidad: cant,
      observacion: observacion || actividadPractica || '',
      idUsuario: (req as any).usuario?.idUsuario ?? 1
    })

    // 2. Si es despacho académico, guardar detalle en tbl_consumo
    if (tipo === 'Despacho' && idAsignatura && idDocente) {
      await Consumo.create({
        idMovimiento: nuevoMovimiento.idMovimiento,
        idAsignatura: Number(idAsignatura),
        idDocente: Number(idDocente),
        actividadPractica: actividadPractica || 'Práctica de laboratorio'
      })
    }

    // 3. Descontar (o sumar si es Devolución/Ingreso) saldo en tbl_lote
    const nuevoStockLote =
      tipo === 'Despacho'
        ? Math.max(0, stockLoteActual - cant)
        : stockLoteActual + cant

    await lote.update({ stockDisponible: nuevoStockLote })

    // 4. Actualizar stock acumulado en tbl_reactivo
    const reactivo = await Reactivo.findByPk(Number(lote.idReactivo))
    if (reactivo) {
      const stockReactivoActual = Number(reactivo.cantidadDisponible ?? 0)
      const nuevoStockReactivo =
        tipo === 'Despacho'
          ? Math.max(0, stockReactivoActual - cant)
          : stockReactivoActual + cant

      await reactivo.update({ cantidadDisponible: nuevoStockReactivo })
    }

    res.status(201).json({ data: nuevoMovimiento })
  } catch (error) {
    console.error('Error al registrar despacho/movimiento:', error)
    res.status(500).json({ message: 'Error al registrar el movimiento' })
  }
}