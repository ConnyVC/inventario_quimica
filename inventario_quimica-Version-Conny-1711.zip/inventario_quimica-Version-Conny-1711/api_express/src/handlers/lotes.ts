import { Request, Response } from 'express'
import Lote from '../models/Lote'
import Marca from '../models/Marca'
import Reactivo from '../models/Reactivo'

export const getMarcas = async (req: Request, res: Response) => {
  try {
    const marcas = await Marca.findAll({
      where: { estado: 1 },
      order: [['nombreMarca', 'ASC']]
    })
    res.json({ data: marcas })
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: 'Error al obtener las marcas' })
  }
}

export const getLotes = async (req: Request, res: Response) => {
  try {
    const lotes = await Lote.findAll({
      order: [['fechaVencimiento', 'ASC']]
    })
    res.json({ data: lotes })
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: 'Error al obtener los lotes' })
  }
}

export const createLote = async (req: Request, res: Response) => {
  try {
    const {
      idReactivo,
      idMarca,
      fechaIngreso,
      fechaVencimiento,
      cantidadIngresada,
      stockDisponible
    } = req.body

    const cantidad = Number(cantidadIngresada)

    const nuevoLote = await Lote.create({
      idReactivo: Number(idReactivo),
      idMarca: Number(idMarca),
      fechaIngreso,
      fechaVencimiento,
      cantidadIngresada: cantidad,
      stockDisponible: stockDisponible !== undefined ? Number(stockDisponible) : cantidad
    })

    // Actualizar stock acumulado en tbl_reactivo
    const reactivo = await Reactivo.findByPk(Number(idReactivo))
    if (reactivo) {
      const stockActual = Number(reactivo.cantidadDisponible ?? 0)
      await reactivo.update({
        cantidadDisponible: stockActual + cantidad
      })
    }

    res.status(201).json({ data: nuevoLote })
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: 'Error al registrar el lote' })
  }
}