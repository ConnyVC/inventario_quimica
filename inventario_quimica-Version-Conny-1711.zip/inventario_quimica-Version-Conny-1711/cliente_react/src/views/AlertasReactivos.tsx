import { useLoaderData, Link } from 'react-router-dom';
import { getReactivos } from '../services/ReactivoService';
import axiosInstance from '../services/axiosInstance';
import type { Reactivo } from '../types/reactivo';

interface LoteAlerta {
  idLote: number | string;
  codigoLote: string;
  idReactivo: number;
  nombreReactivo: string;
  fechaVencimiento: string;
  fechaFormateada: string;
  stockDisponible: number;
  unidadMedida: string;
  diasRestantes: number;
}

function calcularDiasRestantes(fechaStr: string): number {
  if (!fechaStr) return 999;
  const soloFecha = fechaStr.split('T')[0];
  const [anio, mes, dia] = soloFecha.split('-').map(Number);
  const fechaVenc = new Date(anio, mes - 1, dia);

  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0);

  const diffMs = fechaVenc.getTime() - hoy.getTime();
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
}

function formatearFechaCL(fechaStr: string): string {
  if (!fechaStr) return 'Sin fecha';
  const soloFecha = fechaStr.split('T')[0];
  const [anio, mes, dia] = soloFecha.split('-');
  return `${dia}/${mes}/${anio}`;
}

export async function loader() {
  const [reactivos, lotesRes] = await Promise.all([
    getReactivos(),
    axiosInstance.get('/lotes').catch(() => ({ data: [] }))
  ]);

  const rawLotes = Array.isArray(lotesRes.data)
    ? lotesRes.data
    : lotesRes.data?.data || lotesRes.data?.lotes || [];

  const lotesMapeados: LoteAlerta[] = rawLotes.map((l: any) => {
    const idLote = l.idLote ?? l.id_lote ?? l.id;
    const idReactivo = Number(l.idReactivo ?? l.id_reactivo ?? 0);
    const reactivoAsociado = reactivos.find((r) => Number(r.idReactivo) === idReactivo);
    const fechaVenc = l.fechaVencimiento ?? l.fecha_vencimiento ?? '';

    return {
      idLote,
      codigoLote: l.codigoLote ?? l.codigo_lote ?? `LT-${String(idLote).padStart(3, '0')}`,
      idReactivo,
      nombreReactivo:
        l.nombreQuimico ??
        l.reactivo?.nombreQuimico ??
        reactivoAsociado?.nombreQuimico ??
        `Reactivo #${idReactivo}`,
      fechaVencimiento: fechaVenc,
      fechaFormateada: formatearFechaCL(fechaVenc),
      stockDisponible: Number(l.stockDisponible ?? l.stock_disponible ?? 0),
      unidadMedida: reactivoAsociado?.unidadMedida ?? l.unidadMedida ?? 'unid',
      diasRestantes: calcularDiasRestantes(fechaVenc)
    };
  });

  return { reactivos, lotes: lotesMapeados };
}

export default function AlertasOperativas() {
  const { reactivos, lotes } = useLoaderData() as {
    reactivos: Reactivo[];
    lotes: LoteAlerta[];
  };

  // RF04: Stock disponible <= Punto de reorden (solo reactivos habilitados)
  const reactivosCriticos = reactivos
    .filter((r) => {
      const habilitado = Number(r.estado ?? 1) === 1;
      const stock = Number(r.cantidadDisponible ?? r.stockReal ?? 0);
      const reorden = Number(r.puntoReordenMinimo ?? r.puntoCritico ?? 0);
      return habilitado && stock <= reorden;
    })
    .sort((a, b) => {
      const defA = Number(a.cantidadDisponible ?? a.stockReal ?? 0) - Number(a.puntoReordenMinimo ?? a.puntoCritico ?? 0);
      const defB = Number(b.cantidadDisponible ?? b.stockReal ?? 0) - Number(b.puntoReordenMinimo ?? b.puntoCritico ?? 0);
      return defA - defB;
    });

  // RF05: Lotes con saldo > 0 que vencen en <= 30 días (o ya vencidos)
  const lotesProximosVencer = lotes
    .filter((l) => l.stockDisponible > 0 && l.diasRestantes <= 30)
    .sort((a, b) => a.diasRestantes - b.diasRestantes);

  return (
    <div className="container mt-4 mb-5">
      {/* Encabezado */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 className="fw-bold text-dark m-0">Centro de Monitoreo y Alertas Operativas</h2>
          <p className="text-muted small m-0">
            Detección automática de insumos bajo punto de reorden y lotes próximos a vencer
          </p>
        </div>
        
      </div>

      <div className="row g-4">
        {/* Tarjeta Izquierda: Stock Crítico (RF04) */}
        <div className="col-lg-6">
          <div className="card shadow-sm border-0 h-100">
            <div className="card-header bg-danger text-white d-flex justify-content-between align-items-center py-3">
              <span className="fw-bold"> Insumos en Nivel Crítico (RF04)</span>
              <span className="badge bg-white text-danger rounded-pill px-3">
                {reactivosCriticos.length} {reactivosCriticos.length === 1 ? 'Reactivo' : 'Reactivos'}
              </span>
            </div>

            <div className="table-responsive">
              <table className="table table-hover align-middle mb-0">
                <thead className="table-light text-secondary text-uppercase small fw-bold">
                  <tr>
                    <th>Reactivo</th>
                    <th>Disponible</th>
                    <th>Pto. Reorden</th>
                    <th>Déficit</th>
                    <th className="text-end">Acción</th>
                  </tr>
                </thead>
                <tbody>
                  {reactivosCriticos.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center py-4 text-muted">
                         Todos los reactivos superan su punto de reorden mínimo.
                      </td>
                    </tr>
                  ) : (
                    reactivosCriticos.map((r) => {
                      const stock = Number(r.cantidadDisponible ?? r.stockReal ?? 0);
                      const reorden = Number(r.puntoReordenMinimo ?? r.puntoCritico ?? 0);
                      const deficit = Number((stock - reorden).toFixed(2));

                      return (
                        <tr key={r.idReactivo}>
                          <td>
                            <span className="fw-bold d-block text-dark">{r.nombreQuimico}</span>
                            <small className="text-muted font-monospace">
                              {r.formulaQuimica || r.ubicacion || 'Sin fórmula'}
                            </small>
                          </td>
                          <td>
                            <span className="fw-bold text-danger">
                              {stock} {r.unidadMedida}
                            </span>
                          </td>
                          <td className="text-muted">
                            {reorden} {r.unidadMedida}
                          </td>
                          <td>
                            <span className="badge bg-danger-subtle text-danger border border-danger-subtle rounded-pill px-2">
                              {deficit} {r.unidadMedida}
                            </span>
                          </td>
                          <td className="text-end">
                           <Link
                            to={`/movimientos?reponer=${r.idReactivo}`}
                            className="btn btn-outline-primary btn-sm px-3"
                            >
                            Reponer
                            </Link>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Tarjeta Derecha: Vencimientos Proactivos (RF05) */}
        <div className="col-lg-6">
          <div className="card shadow-sm border-0 h-100">
            <div className="card-header bg-warning text-dark d-flex justify-content-between align-items-center py-3">
              <span className="fw-bold"> Lotes Próximos a Vencer (≤ 30 días) (RF05)</span>
              <span className="badge bg-dark text-warning rounded-pill px-3">
                {lotesProximosVencer.length} {lotesProximosVencer.length === 1 ? 'Lote Crítico' : 'Lotes Críticos'}
              </span>
            </div>

            <div className="table-responsive">
              <table className="table table-hover align-middle mb-0">
                <thead className="table-light text-secondary text-uppercase small fw-bold">
                  <tr>
                    <th>Lote</th>
                    <th>Reactivo</th>
                    <th>F. Caducidad</th>
                    <th>Días Restantes</th>
                    <th className="text-end">Prioridad</th>
                  </tr>
                </thead>
                <tbody>
                  {lotesProximosVencer.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center py-4 text-muted">
                         No hay lotes próximos a vencer dentro de los próximos 30 días.
                      </td>
                    </tr>
                  ) : (
                    lotesProximosVencer.map((lote) => {
                      const estaVencido = lote.diasRestantes < 0;
                      const venceHoy = lote.diasRestantes === 0;

                      return (
                        <tr key={lote.idLote}>
                          <td className="fw-bold text-dark font-monospace">{lote.codigoLote}</td>
                          <td>
                            <span className="fw-semibold text-dark">{lote.nombreReactivo}</span>
                            <small className="d-block text-muted">
                              Saldo: {lote.stockDisponible} {lote.unidadMedida}
                            </small>
                          </td>
                          <td className="text-danger fw-semibold">{lote.fechaFormateada}</td>
                          <td>
                            {estaVencido ? (
                              <span className="badge bg-danger rounded-pill px-2">
                                Vencido ({Math.abs(lote.diasRestantes)}d)
                              </span>
                            ) : venceHoy ? (
                              <span className="badge bg-danger rounded-pill px-2">
                                Vence hoy
                              </span>
                            ) : (
                              <span className="badge bg-warning text-dark rounded-pill px-2">
                                {lote.diasRestantes} días restantes
                              </span>
                            )}
                          </td>
                          <td className="text-end">
                            {estaVencido ? (
                              <Link
                                to="/movimientos"
                                className="badge bg-dark text-white text-decoration-none rounded-pill px-3 py-2"
                              >
                                Dar de Baja
                              </Link>
                            ) : (
                              <span className="badge bg-danger rounded-pill px-3 py-2">
                                Priorizar Uso
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}