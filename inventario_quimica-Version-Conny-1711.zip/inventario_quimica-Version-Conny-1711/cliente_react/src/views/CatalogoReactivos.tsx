import { useState } from 'react';
import { useLoaderData, Link } from 'react-router-dom';
import { getReactivos } from '../services/ReactivoService';
import axiosInstance from '../services/axiosInstance';
import type { Reactivo } from '../types/reactivo';

interface CategoriaOption {
  idCategoria: number;
  nombreCategoria: string;
}

export async function loader() {
  const [reactivos, categoriasRes] = await Promise.all([
    getReactivos(),
    axiosInstance.get('/categorias').catch(() => ({ data: [] }))
  ]);

  const rawCategorias = Array.isArray(categoriasRes.data)
    ? categoriasRes.data
    : categoriasRes.data?.data || categoriasRes.data?.categorias || [];

  const categorias: CategoriaOption[] = rawCategorias.map((c: any) => ({
    idCategoria: Number(c.idCategoria ?? c.id_categoria ?? c.id ?? 0),
    nombreCategoria: c.nombreCategoria ?? c.nombre_categoria ?? 'Sin categoría'
  }));

  return { reactivos, categorias };
}

export default function CatalogoReactivos() {
  const { reactivos, categorias } = useLoaderData() as {
    reactivos: Reactivo[];
    categorias: CategoriaOption[];
  };

  const [busqueda, setBusqueda] = useState('');
  const [categoriaFiltro, setCategoriaFiltro] = useState('');
  const [estadoFiltro, setEstadoFiltro] = useState('habilitados');
  const [reactivoSeleccionado, setReactivoSeleccionado] = useState<Reactivo | null>(null);

  const obtenerNombreCategoria = (idCat: number | string, fallback?: string) => {
    if (fallback && fallback.trim() !== '') return fallback;
    const encontrada = categorias.find((c) => c.idCategoria === Number(idCat));
    return encontrada ? encontrada.nombreCategoria : 'Sin clasificar';
  };

  const obtenerColorBadge = (nombre: string) => {
    const texto = nombre.toLowerCase();
    if (texto.includes('mortal') || texto.includes('tóxic') || texto.includes('toxic')) {
      return 'bg-danger';
    }
    if (texto.includes('corrosiv') || texto.includes('inflamable') || texto.includes('comburente')) {
      return 'bg-warning text-dark';
    }
    if (texto.includes('nociv') || texto.includes('atención') || texto.includes('atencion')) {
      return 'bg-info text-dark';
    }
    return 'bg-dark';
  };

  const reactivosFiltrados = reactivos.filter((r) => {
    const nombre = r.nombreQuimico ? r.nombreQuimico.toLowerCase() : '';
    const formula = r.formulaQuimica ? r.formulaQuimica.toLowerCase() : '';
    const termino = busqueda.toLowerCase();

    const coincideBusqueda = nombre.includes(termino) || formula.includes(termino);

    const coincideCategoria =
      categoriaFiltro === '' || String(r.idCategoria) === categoriaFiltro;

    const coincideEstado =
      estadoFiltro === 'todos' ||
      (estadoFiltro === 'habilitados' && Number(r.estado ?? 1) === 1);

    return coincideBusqueda && coincideCategoria && coincideEstado;
  });

  return (
    <div className="container mt-4 mb-5">
      {/* Encabezado */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2 className="fw-bold text-dark m-0">Catálogo Maestro Reactivos e Insumos Químicos</h2>
          <p className="text-muted small m-0">
            Fichas técnicas, clasificación GHS de peligrosidad y disponibilidad en bodega
          </p>
        </div>
        <div className="d-flex gap-2">
          <button
            type="button"
            onClick={() => window.print()}
            className="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1"
          >
            Imprimir Catálogo
          </button>
          <Link to="/reactivos/nuevo" className="btn btn-primary btn-sm d-flex align-items-center gap-1">
             Agregar al Catálogo
          </Link>
        </div>
      </div>

      {/* Barra de Filtros */}
      <div className="card card-body shadow-sm border-0 mb-4 bg-light">
        <div className="row g-3">
          <div className="col-md-5">
            <div className="input-group">
              
              <input
                type="text"
                className="form-control border-start-0 ps-0"
                placeholder="Buscar por reactivo o fórmula química..."
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
              />
            </div>
          </div>
          <div className="col-md-4">
            <select
              className="form-select"
              value={categoriaFiltro}
              onChange={(e) => setCategoriaFiltro(e.target.value)}
            >
              <option value="">Todas las clasificaciones de peligro</option>
              {categorias.map((cat) => (
                <option key={cat.idCategoria} value={String(cat.idCategoria)}>
                  {cat.nombreCategoria}
                </option>
              ))}
            </select>
          </div>
          <div className="col-md-3">
            <select
              className="form-select"
              value={estadoFiltro}
              onChange={(e) => setEstadoFiltro(e.target.value)}
            >
              <option value="habilitados">Solo Reactivos Habilitados</option>
              <option value="todos">Todos los Estados</option>
            </select>
          </div>
        </div>
      </div>

      {/* Tabla del Catálogo */}
      <div className="card shadow-sm border-0">
        <div className="table-responsive">
          <table className="table table-hover align-middle mb-0">
            <thead className="table-light text-secondary text-uppercase small fw-bold">
              <tr>
                <th>ID</th>
                <th>Sustancia Química</th>
                <th>Fórmula Molecular</th>
                <th>Peligrosidad GHS</th>
                <th>Ubicación</th>
                <th>Stock Acumulado</th>
                <th>Pto. Reorden</th>
                <th className="text-end">Ficha / Acciones</th>
              </tr>
            </thead>
            <tbody>
              {reactivosFiltrados.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-4 text-muted">
                    No se encontraron reactivos que coincidan con los filtros aplicados.
                  </td>
                </tr>
              ) : (
                reactivosFiltrados.map((r) => {
                  const stock = Number(r.cantidadDisponible ?? r.stockReal ?? 0);
                  const reorden = Number(r.puntoReordenMinimo ?? r.puntoCritico ?? 0);
                  const esCritico = stock <= reorden;
                  const nombrePeligro = obtenerNombreCategoria(r.idCategoria, r.categoriaPeligrosidad);

                  return (
                    <tr key={r.idReactivo}>
                      <td className="fw-bold text-muted">#{r.idReactivo}</td>
                      <td>
                        <span className="fw-bold d-block text-dark">{r.nombreQuimico}</span>
                        <small className="text-muted">Insumo / Reactivo de bodega</small>
                      </td>
                      <td>
                        <span className="text-danger fw-semibold font-monospace">
                          {r.formulaQuimica || 'S/F'}
                        </span>
                      </td>
                      <td>
                        <span className={`badge rounded-pill px-3 py-2 ${obtenerColorBadge(nombrePeligro)}`}>
                           {nombrePeligro}
                        </span>
                      </td>
                      <td>
                        <span className="badge bg-light text-dark border font-monospace">
                          {r.ubicacion || 'Sin asignar'}
                        </span>
                      </td>
                      <td>
                        <span className={`fw-bold ${esCritico ? 'text-danger' : 'text-dark'}`}>
                          {stock} {r.unidadMedida}
                        </span>
                      </td>
                      <td className="text-muted">
                        {reorden} {r.unidadMedida}
                      </td>
                      <td className="text-end">
                        <div className="d-flex justify-content-end gap-1">
                          <button
                            type="button"
                            onClick={() => setReactivoSeleccionado(r)}
                            className="btn btn-outline-info btn-sm rounded-pill px-2"
                          >
                           Ficha
                          </button>
                          <Link
                            to={`/reactivos/${r.idReactivo}/editar`}
                            className="btn btn-outline-secondary btn-sm rounded-circle"
                          >
                            <span>Editar</span>
                          </Link>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal de Ficha Técnica */}
      {reactivoSeleccionado && (
        <div className="modal fade show d-block bg-dark bg-opacity-50" tabIndex={-1}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title fw-bold">
                   Ficha Técnica: {reactivoSeleccionado.nombreQuimico}
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => setReactivoSeleccionado(null)}
                />
              </div>
              <div className="modal-body">
                <p><strong>Fórmula Química:</strong> {reactivoSeleccionado.formulaQuimica || 'No registrada'}</p>
                <p>
                  <strong>Clasificación de Peligrosidad:</strong>{' '}
                  {obtenerNombreCategoria(
                    reactivoSeleccionado.idCategoria,
                    reactivoSeleccionado.categoriaPeligrosidad
                  )}
                </p>
                <p>
                  <strong>Stock Real en Bodega:</strong>{' '}
                  {reactivoSeleccionado.cantidadDisponible ?? reactivoSeleccionado.stockReal}{' '}
                  {reactivoSeleccionado.unidadMedida}
                </p>
                <p>
                  <strong>Punto de Reorden Mínimo:</strong>{' '}
                  {reactivoSeleccionado.puntoReordenMinimo ?? reactivoSeleccionado.puntoCritico}{' '}
                  {reactivoSeleccionado.unidadMedida}
                </p>
                <p>
                  <strong>Ubicación Asignada:</strong>{' '}
                  {reactivoSeleccionado.ubicacion || 'Sin asignar'}
                </p>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary btn-sm"
                  onClick={() => setReactivoSeleccionado(null)}
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}