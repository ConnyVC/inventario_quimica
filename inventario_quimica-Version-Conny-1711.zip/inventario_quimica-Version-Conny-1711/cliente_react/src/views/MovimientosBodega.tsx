import { useState, useEffect } from 'react';
import { useLoaderData, useSearchParams, useActionData, Form, Link } from 'react-router-dom';
import { getReactivos } from '../services/ReactivoService';
import axiosInstance from '../services/axiosInstance';
import type { Reactivo } from '../types/reactivo';

interface LoteItem {
  idLote: number;
  codigoLote: string;
  idReactivo: number;
  nombreReactivo: string;
  unidadMedida: string;
  nombreMarca: string;
  fechaIngreso: string;
  fechaVencimiento: string;
  cantidadIngresada: number;
  stockDisponible: number;
  diasRestantes: number;
}

interface MovimientoItem {
  idMovimiento: number;
  tipoMovimiento: string;
  fechaMovimiento: string;
  nombreReactivo: string;
  codigoLote: string;
  cantidad: number;
  unidadMedida: string;
  observacion: string;
}

interface OpcionSelect {
  id: number;
  nombre: string;
}

function calcularDiasRestantes(fechaStr: string): number {
  if (!fechaStr) return 999;
  const [anio, mes, dia] = fechaStr.split('T')[0].split('-').map(Number);
  const fechaVenc = new Date(anio, mes - 1, dia);
  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0);
  return Math.ceil((fechaVenc.getTime() - hoy.getTime()) / (1000 * 60 * 60 * 24));
}

function formatearFecha(fechaStr: string): string {
  if (!fechaStr) return '-';
  const partes = fechaStr.split('T')[0].split('-');
  return partes.length === 3 ? `${partes[2]}/${partes[1]}/${partes[0]}` : fechaStr;
}

export async function loader() {
  const [reactivos, lotesRes, movsRes, marcasRes, asignaturasRes, docentesRes] = await Promise.all([
    getReactivos(),
    axiosInstance.get('/lotes').catch(() => ({ data: [] })),
    axiosInstance.get('/movimientos').catch(() => ({ data: [] })),
    axiosInstance.get('/marcas').catch(() => ({ data: [] })),
    axiosInstance.get('/asignaturas').catch(() => ({ data: [] })),
    axiosInstance.get('/docentes').catch(() => ({ data: [] })),
  ]);

  const extractArray = (res: any) =>
    Array.isArray(res.data) ? res.data : res.data?.data || [];

  const marcas: OpcionSelect[] = extractArray(marcasRes).map((m: any) => ({
    id: Number(m.idMarca ?? m.id_marca ?? m.id),
    nombre: m.nombreMarca ?? m.nombre_marca ?? 'Sin marca',
  }));

  const asignaturas: OpcionSelect[] = extractArray(asignaturasRes).map((a: any) => ({
    id: Number(a.idAsignatura ?? a.id_asignatura ?? a.id),
    nombre: `${a.codigoAsignatura ?? a.codigo_asignatura ?? ''} - ${a.nombreAsignatura ?? a.nombre_asignatura ?? ''}`.trim(),
  }));

  const docentes: OpcionSelect[] = extractArray(docentesRes).map((d: any) => ({
    id: Number(d.idDocente ?? d.id_docente ?? d.id),
    nombre: `${d.nombres ?? ''} ${d.apellidoPaterno ?? d.apellido_paterno ?? ''}`.trim(),
  }));

  const lotes: LoteItem[] = extractArray(lotesRes).map((l: any) => {
    const idLote = Number(l.idLote ?? l.id_lote ?? l.id);
    const idReactivo = Number(l.idReactivo ?? l.id_reactivo ?? 0);
    const idMarca = Number(l.idMarca ?? l.id_marca ?? 0);
    const reactivo = reactivos.find((r) => Number(r.idReactivo) === idReactivo);
    const marca = marcas.find((m) => m.id === idMarca);
    const fechaVenc = l.fechaVencimiento ?? l.fecha_vencimiento ?? '';

    return {
      idLote,
      codigoLote: l.codigoLote ?? l.codigo_lote ?? `LT-${String(idLote).padStart(3, '0')}`,
      idReactivo,
      nombreReactivo: reactivo?.nombreQuimico ?? l.nombreQuimico ?? `Reactivo #${idReactivo}`,
      unidadMedida: reactivo?.unidadMedida ?? 'unid',
      nombreMarca: marca?.nombre ?? l.nombreMarca ?? l.marca?.nombreMarca ?? 'Genérica',
      fechaIngreso: formatearFecha(l.fechaIngreso ?? l.fecha_ingreso ?? ''),
      fechaVencimiento: formatearFecha(fechaVenc),
      cantidadIngresada: Number(l.cantidadIngresada ?? l.cantidad_ingresada ?? 0),
      stockDisponible: Number(l.stockDisponible ?? l.stock_disponible ?? 0),
      diasRestantes: calcularDiasRestantes(fechaVenc),
    };
  });

  const movimientos: MovimientoItem[] = extractArray(movsRes).map((m: any) => {
    const idMov = Number(m.idMovimiento ?? m.id_movimiento ?? m.id);
    const idLote = Number(m.idLote ?? m.id_lote ?? 0);
    const lote = lotes.find((lt) => lt.idLote === idLote);

    return {
      idMovimiento: idMov,
      tipoMovimiento: m.tipoMovimiento ?? m.tipo_movimiento ?? 'Movimiento',
      fechaMovimiento: formatearFecha(m.fechaMovimiento ?? m.fecha_movimiento ?? ''),
      nombreReactivo: lote?.nombreReactivo ?? m.nombreQuimico ?? 'Reactivo',
      codigoLote: lote?.codigoLote ?? `LT-${String(idLote).padStart(3, '0')}`,
      cantidad: Number(m.cantidad ?? 0),
      unidadMedida: lote?.unidadMedida ?? 'unid',
      observacion: m.observacion ?? '-',
    };
  });

  return { reactivos, lotes, movimientos, marcas, asignaturas, docentes };
}

export async function action({ request }: { request: Request }) {
  const formData = await request.formData();
  const data = Object.fromEntries(formData);
  const tipoOperacion = String(data.tipoOperacion || '');

  try {
    if (tipoOperacion === 'recepcionar_lote') {
      const cantidad = Number(data.cantidadIngresada);
      await axiosInstance.post('/lotes', {
        idReactivo: Number(data.idReactivo),
        idMarca: Number(data.idMarca || 1),
        fechaIngreso: data.fechaIngreso,
        fechaVencimiento: data.fechaVencimiento,
        cantidadIngresada: cantidad,
        stockDisponible: cantidad,
      });
      return { ok: true, mensaje: 'Nuevo lote recepcionado y stock actualizado correctamente.' };
    }

    if (tipoOperacion === 'despacho_docencia') {
      await axiosInstance.post('/movimientos', {
        idLote: Number(data.idLote),
        tipoMovimiento: 'Despacho',
        cantidad: Number(data.cantidad),
        idAsignatura: Number(data.idAsignatura),
        idDocente: Number(data.idDocente),
        actividadPractica: String(data.actividadPractica || ''),
        observacion: String(data.observacion || ''),
      });
      return { ok: true, mensaje: 'Salida / despacho registrado con trazabilidad académica.' };
    }

    if (tipoOperacion === 'declarar_merma') {
      await axiosInstance.post('/mermas', {
        idLote: Number(data.idLote),
        tipoAjuste: String(data.tipoAjuste || 'Salida'),
        motivoAjuste: String(data.motivoAjuste || 'Vencimiento'),
        cantidadAfectada: Number(data.cantidadAfectada),
        observacion: String(data.observacion || ''),
      });
      return { ok: true, mensaje: 'Ajuste / merma registrado correctamente en el inventario.' };
    }

    return { ok: false, error: 'Operación no reconocida.' };
  } catch (error: any) {
    console.error('Error en operación de bodega:', error);
    return {
      ok: false,
      error: error?.response?.data?.message || 'No se pudo registrar la operación en el servidor.',
    };
  }
}

export default function MovimientosBodega() {
  const { reactivos, lotes, movimientos, marcas, asignaturas, docentes } = useLoaderData() as {
    reactivos: Reactivo[];
    lotes: LoteItem[];
    movimientos: MovimientoItem[];
    marcas: OpcionSelect[];
    asignaturas: OpcionSelect[];
    docentes: OpcionSelect[];
  };

  const actionData = useActionData() as { ok?: boolean; mensaje?: string; error?: string } | undefined;
  const [searchParams, setSearchParams] = useSearchParams();

  const [tabActiva, setTabActiva] = useState<'lotes' | 'bitacora'>('lotes');
  const [modalAbierto, setModalAbierto] = useState<'lote' | 'despacho' | 'merma' | null>(null);
  const [reactivoPreseleccionado, setReactivoPreseleccionado] = useState<string>('');
  const [lotePreseleccionado, setLotePreseleccionado] = useState<string>('');

  // Detectar si venimos desde el botón "Reponer" o "Dar de Baja" de Alertas
  useEffect(() => {
    const idReponer = searchParams.get('reponer');
    const idMerma = searchParams.get('merma');

    if (idReponer) {
      setReactivoPreseleccionado(idReponer);
      setModalAbierto('lote');
    } else if (idMerma) {
      setLotePreseleccionado(idMerma);
      setModalAbierto('merma');
    }
  }, [searchParams]);

  // Cerrar modal automáticamente si el POST fue exitoso
  useEffect(() => {
    if (actionData?.ok) {
      cerrarModal();
    }
  }, [actionData]);

  const cerrarModal = () => {
    setModalAbierto(null);
    setReactivoPreseleccionado('');
    setLotePreseleccionado('');
    if (searchParams.has('reponer') || searchParams.has('merma')) {
      setSearchParams({});
    }
  };

  const hoyISO = new Date().toISOString().split('T')[0];

  return (
    <div className="container mt-4 mb-5">
      {/* Encabezado */}
      <div className="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
          <h2 className="fw-bold text-dark m-0">Gestión de Lotes y Movimientos de Bodega</h2>
          <p className="text-muted small m-0">
            Recepción de compras, control físico de envases y ajuste de mermas
          </p>
        </div>
        <div className="d-flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setModalAbierto('lote')}
            className="btn btn-primary btn-sm d-flex align-items-center gap-1"
          >
             Recepcionar Nuevo Lote
          </button>
          <button
            type="button"
            onClick={() => setModalAbierto('despacho')}
            className="btn btn-outline-dark btn-sm d-flex align-items-center gap-1"
          >
             Registrar Despacho
          </button>
          <button
            type="button"
            onClick={() => setModalAbierto('merma')}
            className="btn btn-danger btn-sm d-flex align-items-center gap-1"
          >
            Declarar Merma / Ajuste
          </button>
          <Link to="/catalogo" className="btn btn-outline-secondary btn-sm">
            ← Volver al Catálogo
          </Link>
        </div>
      </div>

      {/* Feedback de operación */}
      {actionData?.mensaje && (
        <div className="alert alert-success alert-dismissible fade show" role="alert">
          ✅ {actionData.mensaje}
        </div>
      )}
      {actionData?.error && (
        <div className="alert alert-danger alert-dismissible fade show" role="alert">
          ⚠️ {actionData.error}
        </div>
      )}

      {/* Pestañas de navegación */}
      <div className="d-flex gap-2 mb-3">
        <button
          type="button"
          onClick={() => setTabActiva('lotes')}
          className={`btn btn-sm fw-semibold ${
            tabActiva === 'lotes' ? 'btn-primary' : 'btn-outline-secondary border-0'
          }`}
        >
           Lotes Físicos Vigentes (tbl_lote)
        </button>
        <button
          type="button"
          onClick={() => setTabActiva('bitacora')}
          className={`btn btn-sm fw-semibold ${
            tabActiva === 'bitacora' ? 'btn-primary' : 'btn-outline-secondary border-0'
          }`}
        >
           Bitácora de Transacciones (tbl_movimiento)
        </button>
      </div>

      {/* Tabla 1: Lotes Físicos */}
      {tabActiva === 'lotes' && (
        <div className="card shadow-sm border-0">
          <div className="table-responsive">
            <table className="table table-hover align-middle mb-0">
              <thead className="table-light text-secondary text-uppercase small fw-bold">
                <tr>
                  <th>N° Lote</th>
                  <th>Reactivo</th>
                  <th>Marca / Fabricante</th>
                  <th>F. Ingreso</th>
                  <th>F. Vencimiento</th>
                  <th>Cant. Inicial</th>
                  <th>Stock Actual</th>
                  <th>Estado</th>
                </tr>
              </thead>
              <tbody>
                {lotes.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-4 text-muted">
                      No hay lotes físicos registrados en bodega. Usa "Recepcionar Nuevo Lote" para ingresar stock.
                    </td>
                  </tr>
                ) : (
                  lotes.map((l) => {
                    const vencido = l.diasRestantes < 0;
                    const proximo = l.diasRestantes >= 0 && l.diasRestantes <= 30;

                    return (
                      <tr key={l.idLote}>
                        <td className="fw-bold font-monospace">{l.codigoLote}</td>
                        <td className="fw-semibold text-dark">{l.nombreReactivo}</td>
                        <td className="text-uppercase small text-muted">{l.nombreMarca}</td>
                        <td>{l.fechaIngreso}</td>
                        <td className={vencido || proximo ? 'text-danger fw-semibold' : ''}>
                          {l.fechaVencimiento}
                        </td>
                        <td>
                          {l.cantidadIngresada} {l.unidadMedida}
                        </td>
                        <td>
                          <span className={`fw-bold ${proximo || vencido ? 'text-warning' : 'text-success'}`}>
                            {l.stockDisponible} {l.unidadMedida}
                          </span>
                        </td>
                        <td>
                          {vencido ? (
                            <span className="badge bg-danger rounded-pill px-3">Vencido</span>
                          ) : proximo ? (
                            <span className="badge bg-warning text-dark rounded-pill px-3">
                              Próximo a Vencer
                            </span>
                          ) : (
                            <span className="badge bg-success rounded-pill px-3">Vigente</span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tabla 2: Bitácora de Transacciones */}
      {tabActiva === 'bitacora' && (
        <div className="card shadow-sm border-0">
          <div className="table-responsive">
            <table className="table table-hover align-middle mb-0">
              <thead className="table-light text-secondary text-uppercase small fw-bold">
                <tr>
                  <th>ID</th>
                  <th>Tipo</th>
                  <th>Fecha</th>
                  <th>Reactivo / Lote</th>
                  <th>Cantidad</th>
                  <th>Observación</th>
                </tr>
              </thead>
              <tbody>
                {movimientos.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-4 text-muted">
                      Aún no existen movimientos registrados en la bitácora.
                    </td>
                  </tr>
                ) : (
                  movimientos.map((m) => (
                    <tr key={m.idMovimiento}>
                      <td className="text-muted fw-bold">#{m.idMovimiento}</td>
                      <td>
                        <span
                          className={`badge rounded-pill px-3 ${
                            m.tipoMovimiento === 'Ingreso'
                              ? 'bg-success'
                              : m.tipoMovimiento === 'Despacho'
                              ? 'bg-primary'
                              : 'bg-secondary'
                          }`}
                        >
                          {m.tipoMovimiento}
                        </span>
                      </td>
                      <td>{m.fechaMovimiento}</td>
                      <td>
                        <span className="fw-semibold d-block">{m.nombreReactivo}</span>
                        <small className="text-muted font-monospace">{m.codigoLote}</small>
                      </td>
                      <td className="fw-bold">
                        {m.cantidad} {m.unidadMedida}
                      </td>
                      <td className="text-muted small">{m.observacion}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL 1: Recepcionar Nuevo Lote (RF02 / Reposición desde Alertas) */}
      {modalAbierto === 'lote' && (
        <div className="modal fade show d-block bg-dark bg-opacity-50" tabIndex={-1}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title fw-bold"> Recepcionar Nuevo Lote (Ingreso de Stock)</h5>
                <button type="button" className="btn-close" onClick={cerrarModal} />
              </div>
              <Form method="POST">
                <input type="hidden" name="tipoOperacion" value="recepcionar_lote" />
                <div className="modal-body">
                  <div className="mb-3">
                    <label className="form-label fw-semibold">Reactivo Químico</label>
                    <select
                      name="idReactivo"
                      className="form-select"
                      defaultValue={reactivoPreseleccionado}
                      required
                    >
                      <option value="">-- Seleccione reactivo --</option>
                      {reactivos.map((r) => (
                        <option key={r.idReactivo} value={String(r.idReactivo)}>
                          {r.nombreQuimico} ({r.unidadMedida})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="mb-3">
                    <label className="form-label fw-semibold">Marca / Fabricante</label>
                    <select name="idMarca" className="form-select" required>
                      {marcas.length === 0 ? (
                        <option value="1">Merck / Genérica</option>
                      ) : (
                        marcas.map((m) => (
                          <option key={m.id} value={String(m.id)}>
                            {m.nombre}
                          </option>
                        ))
                      )}
                    </select>
                  </div>

                  <div className="row g-2 mb-3">
                    <div className="col-6">
                      <label className="form-label fw-semibold">Fecha de Ingreso</label>
                      <input
                        type="date"
                        name="fechaIngreso"
                        className="form-control"
                        defaultValue={hoyISO}
                        required
                      />
                    </div>
                    <div className="col-6">
                      <label className="form-label fw-semibold">Fecha de Vencimiento</label>
                      <input
                        type="date"
                        name="fechaVencimiento"
                        className="form-control"
                        required
                      />
                    </div>
                  </div>

                  <div className="mb-2">
                    <label className="form-label fw-semibold">Cantidad Ingresada (según unidad del reactivo)</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0.01"
                      name="cantidadIngresada"
                      className="form-control"
                      placeholder="Ej: 500"
                      required
                    />
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-secondary btn-sm" onClick={cerrarModal}>
                    Cancelar
                  </button>
                  <button type="submit" className="btn btn-primary btn-sm">
                    Guardar Ingreso de Lote
                  </button>
                </div>
              </Form>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Registrar Despacho a Docencia (RF03) */}
      {modalAbierto === 'despacho' && (
        <div className="modal fade show d-block bg-dark bg-opacity-50" tabIndex={-1}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title fw-bold"> Registrar Salida / Despacho a Cátedra</h5>
                <button type="button" className="btn-close" onClick={cerrarModal} />
              </div>
              <Form method="POST">
                <input type="hidden" name="tipoOperacion" value="despacho_docencia" />
                <div className="modal-body">
                  <div className="mb-3">
                    <label className="form-label fw-semibold">Lote Físico a Descontar</label>
                    <select name="idLote" className="form-select" required>
                      <option value="">-- Seleccione lote con saldo --</option>
                      {lotes
                        .filter((l) => l.stockDisponible > 0)
                        .map((l) => (
                          <option key={l.idLote} value={String(l.idLote)}>
                            {l.codigoLote} - {l.nombreReactivo} (Disp: {l.stockDisponible} {l.unidadMedida})
                          </option>
                        ))}
                    </select>
                  </div>

                  <div className="row g-2 mb-3">
                    <div className="col-6">
                      <label className="form-label fw-semibold">Asignatura</label>
                      <select name="idAsignatura" className="form-select" required>
                        <option value="">-- Seleccione ramo --</option>
                        {asignaturas.map((a) => (
                          <option key={a.id} value={String(a.id)}>
                            {a.nombre}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="col-6">
                      <label className="form-label fw-semibold">Docente Responsable</label>
                      <select name="idDocente" className="form-select" required>
                        <option value="">-- Seleccione docente --</option>
                        {docentes.map((d) => (
                          <option key={d.id} value={String(d.id)}>
                            {d.nombre}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="mb-3">
                    <label className="form-label fw-semibold">Actividad Práctica / Laboratorio</label>
                    <input
                      type="text"
                      name="actividadPractica"
                      className="form-control"
                      placeholder="Ej: Laboratorio N°2: Reacciones de Precipitación"
                      required
                    />
                  </div>

                  <div className="mb-2">
                    <label className="form-label fw-semibold">Cantidad Retirada</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0.01"
                      name="cantidad"
                      className="form-control"
                      placeholder="Ej: 50"
                      required
                    />
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-secondary btn-sm" onClick={cerrarModal}>
                    Cancelar
                  </button>
                  <button type="submit" className="btn btn-primary btn-sm">
                    Confirmar Despacho
                  </button>
                </div>
              </Form>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: Declarar Merma / Ajuste (RF07) */}
      {modalAbierto === 'merma' && (
        <div className="modal fade show d-block bg-dark bg-opacity-50" tabIndex={-1}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title fw-bold">🗑️ Declarar Merma o Ajuste de Inventario</h5>
                <button type="button" className="btn-close" onClick={cerrarModal} />
              </div>
              <Form method="POST">
                <input type="hidden" name="tipoOperacion" value="declarar_merma" />
                <div className="modal-body">
                  <div className="mb-3">
                    <label className="form-label fw-semibold">Lote Afectado</label>
                    <select
                      name="idLote"
                      className="form-select"
                      defaultValue={lotePreseleccionado}
                      required
                    >
                      <option value="">-- Seleccione lote --</option>
                      {lotes.map((l) => (
                        <option key={l.idLote} value={String(l.idLote)}>
                          {l.codigoLote} - {l.nombreReactivo} (Saldo: {l.stockDisponible} {l.unidadMedida})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="row g-2 mb-3">
                    <div className="col-6">
                      <label className="form-label fw-semibold">Tipo de Ajuste</label>
                      <select name="tipoAjuste" className="form-select" required>
                        <option value="Salida">Salida (Merma / Baja)</option>
                        <option value="Entrada">Entrada (Ajuste Positivo)</option>
                      </select>
                    </div>
                    <div className="col-6">
                      <label className="form-label fw-semibold">Motivo Codificado</label>
                      <select name="motivoAjuste" className="form-select" required>
                        <option value="Vencimiento">Vencimiento</option>
                        <option value="Contaminación">Contaminación</option>
                        <option value="Quiebre/Deterioro">Quiebre/Deterioro</option>
                        <option value="Ajuste Por Conteo">Ajuste Por Conteo</option>
                        <option value="Otro">Otro</option>
                      </select>
                    </div>
                  </div>

                  <div className="mb-3">
                    <label className="form-label fw-semibold">Cantidad Afectada</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0.01"
                      name="cantidadAfectada"
                      className="form-control"
                      placeholder="Ej: 20"
                      required
                    />
                  </div>

                  <div className="mb-2">
                    <label className="form-label fw-semibold">Justificación / Observación</label>
                    <input
                      type="text"
                      name="observacion"
                      className="form-control"
                      placeholder="Detalle para auditoría interna..."
                      required
                    />
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-secondary btn-sm" onClick={cerrarModal}>
                    Cancelar
                  </button>
                  <button type="submit" className="btn btn-danger btn-sm">
                    Registrar Ajuste
                  </button>
                </div>
              </Form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}