import type { ReactivoSequelize, ReactivoFormPayload } from '../types/reactivo'
const API_URL = 'http://localhost:3000/api/reactivos'

const getHeaders = () => {
  const token = localStorage.getItem('token')
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {})
  }
}

// C - Create
export const crearReactivo = async (payload: ReactivoFormPayload): Promise<void> => {
  const res = await fetch(API_URL, {
    method: 'POST',
    headers: getHeaders(),
    body: JSON.stringify(payload)
  })
  if (!res.ok) throw new Error('Error al registrar reactivo')
}

// R - Read
export const obtenerReactivos = async (): Promise<ReactivoSequelize[]> => {
  const res = await fetch(API_URL, {
    headers: getHeaders()
  })
  if (!res.ok) throw new Error('Error al consultar catálogo')
  return await res.json()
}

// U - Update
export const actualizarReactivo = async (
  id: number,
  payload: ReactivoFormPayload
): Promise<void> => {
  const res = await fetch(`${API_URL}/${id}`, {
    method: 'PUT',
    headers: getHeaders(),
    body: JSON.stringify(payload)
  })
  if (!res.ok) throw new Error('Error al modificar reactivo')
}

// D - Delete (baja lógica)
export const eliminarReactivo = async (id: number): Promise<void> => {
  const res = await fetch(`${API_URL}/${id}`, {
    method: 'DELETE',
    headers: getHeaders()
  })
  if (!res.ok) throw new Error('Error al dar de baja reactivo')
}


// Función auxiliar para registrar una salida / despacho descontando stock
export const registrarSalidaReactivo = async (
  idReactivo: number,
  nuevoStock: number,
  datosActuales: ReactivoFormPayload
): Promise<void> => {
  await actualizarReactivo(idReactivo, {
    ...datosActuales,
    cantidadDisponible: nuevoStock
  })
}