import { CategoriaOption } from '../types/categoria'

const API_URL = 'http://localhost:3000/api/categorias'

export const obtenerCategorias = async (): Promise<CategoriaOption[]> => {
  const token = localStorage.getItem('token')
  const res = await fetch(API_URL, {
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    }
  })

  if (!res.ok) throw new Error('Error al cargar categorías')
  const data = await res.json()
  return Array.isArray(data) ? data : data.data || []
}