import React from 'react'
import type { ReactivoSequelize } from '../types/reactivo'

export interface ReactivoUI {
  idReactivo: number
  nombreQuimico: string
  formulaQuimica: string
  categoriaPeligrosidad: string
  stockReal: number
  unidadMedida: string
  puntoCritico: number
  estadoAlerta: 'Óptimo' | 'Bajo Reorden' | 'Crítico'
}

interface Props {
  item: ReactivoUI
  esAdmin: boolean
  reactivosRaw: ReactivoSequelize[]
  onEditar: (item: ReactivoSequelize) => void
  onEliminar: (id: number, nombre: string) => void
}

export const ReactivoFila: React.FC<Props> = ({
  item,
  esAdmin,
  reactivosRaw,
  onEditar,
  onEliminar
}) => {
  return (
    <tr>
      <td>{item.idReactivo}</td>
      <td className="fw-semibold">{item.nombreQuimico}</td>
      <td>
        <code>{item.formulaQuimica}</code>
      </td>
      <td>
        <span className="badge bg-dark">{item.categoriaPeligrosidad}</span>
      </td>
      <td>{`${item.stockReal} ${item.unidadMedida}`}</td>
      <td>{`${item.puntoCritico} ${item.unidadMedida}`}</td>
      <td>
        <span
          className={`badge ${
            item.estadoAlerta === 'Óptimo' ? 'bg-success' : 'bg-danger'
          }`}
        >
          {item.estadoAlerta}
        </span>
      </td>

      {esAdmin && (
        <td className="text-end">
          <button
            className="btn btn-outline-primary btn-sm border-0 me-1"
            title="Modificar reactivo"
            data-bs-toggle="modal"
            data-bs-target="#modalEditarReactivo"
            onClick={() => {
              const original = reactivosRaw.find((r) => r.idReactivo === item.idReactivo)
              if (original) onEditar(original)
            }}
          >
            <i className="bi bi-pencil"></i>
          </button>
          <button
            className="btn btn-outline-danger btn-sm border-0"
            title="Dar de baja reactivo"
            onClick={() => onEliminar(item.idReactivo, item.nombreQuimico)}
          >
            <i className="bi bi-trash"></i>
          </button>
        </td>
      )}
    </tr>
  )
}