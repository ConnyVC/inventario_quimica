export interface CategoriaBackend {
  idCategoria: number
  nombreCategoria: string
  pictograma?: string
}

export interface CategoriaOption {
  idCategoria: number
  nombreCategoria: string
}