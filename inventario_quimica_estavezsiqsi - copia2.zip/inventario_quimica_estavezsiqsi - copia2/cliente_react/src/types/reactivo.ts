import type { CategoriaBackend } from './categoria'

export interface ReactivoSequelize {
  idReactivo: number
  nombreQuimico: string
  formulaQuimica: string | null
  unidadMedida: string
  puntoReordenMinimo: number | string
  idCategoria: number
  cantidadDisponible: number | string
  estado: number
  categoria?: CategoriaBackend
}

export interface ReactivoUI {
  idReactivo: number
  nombreQuimico: string
  formulaQuimica: string
  categoriaPeligrosidad: string
  stockReal: number
  unidadMedida: string
  puntoCritico: number
  estadoAlerta: 'Óptimo' | 'Bajo Reorden' | 'Crítico'
}

export interface ReactivoFormPayload {
  nombreQuimico: string
  formulaQuimica?: string | null
  unidadMedida: string
  puntoReordenMinimo: number
  idCategoria: number
  cantidadDisponible: number
  estado?: number
}