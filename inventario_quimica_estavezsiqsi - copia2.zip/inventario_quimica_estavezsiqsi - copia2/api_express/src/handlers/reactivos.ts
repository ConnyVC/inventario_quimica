import { Request, Response } from "express"
import Reactivo from '../models/Reactivo'
import CategoriaPeligrosidad from '../models/CategoriaPeligrosidad'

// 1. Listar reactivos activos con su categoría (consumido por Home.tsx)
export const getReactivos = async (req: Request, res: Response) => {
  try {
    const reactivos = await Reactivo.findAll({
      where: { estado: 1 },
      include: [{ 
        model: CategoriaPeligrosidad,
        attributes: ['idCategoria', 'nombreCategoria', 'pictograma']
      }],
      order: [['nombreQuimico', 'ASC']]
    })
    return res.json(reactivos)
  } catch (error) {
    console.error('Error al obtener inventario:', error)
    return res.status(500).json({ error: 'Error al obtener inventario de la bodega' })
  }
}

// 2. Obtener un reactivo por su ID
export const getReactivoById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params
    const reactivo = await Reactivo.findByPk(Number(id), {
      include: [{ model: CategoriaPeligrosidad }]
    })

    if (!reactivo) {
      return res.status(404).json({ error: 'Reactivo no encontrado' })
    }

    return res.json(reactivo)
  } catch (error) {
    console.error('Error al obtener reactivo:', error)
    return res.status(500).json({ error: 'Error al consultar el reactivo' })
  }
}

// 3. Crear nuevo reactivo
export const crearReactivo = async (req: Request, res: Response) => {
  try {
    const reactivoNuevo = await Reactivo.create(req.body)
    return res.status(201).json(reactivoNuevo)
  } catch (error) {
    console.error('Error al crear reactivo:', error)
    return res.status(400).json({ error: 'No se pudo registrar el reactivo. Verifique los campos.' })
  }
}

// 4. Editar un reactivo existente
export const editarReactivo = async (req: Request, res: Response) => {
  try {
    const { id } = req.params
    const reactivo = await Reactivo.findByPk(Number(id))

    if (!reactivo) {
      return res.status(404).json({ error: 'Reactivo no encontrado para editar' })
    }

    await reactivo.update(req.body)
    return res.json(reactivo)
  } catch (error) {
    console.error('Error al editar reactivo:', error)
    return res.status(500).json({ error: 'Error al actualizar el reactivo' })
  }
}

// 5. Borrado (Baja lógica recomendada para mantener la trazabilidad de auditoría)
export const borrarReactivo = async (req: Request, res: Response) => {
  try {
    const { id } = req.params
    const reactivo = await Reactivo.findByPk(Number(id))

    if (!reactivo) {
      return res.status(404).json({ error: 'Reactivo no encontrado para dar de baja' })
    }

    // Se recomienda baja lógica (estado = 0) para no romper relaciones con tbl_lote o tbl_movimiento
    await reactivo.update({ estado: 0 })
    return res.json({ mensaje: 'Reactivo deshabilitado exitosamente del catálogo' })
  } catch (error) {
    console.error('Error al eliminar reactivo:', error)
    return res.status(500).json({ error: 'Error al procesar la baja del reactivo' })
  }
}