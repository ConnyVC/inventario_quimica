import { Router } from "express";
import { 
  borrarReactivo, 
  crearReactivo, 
  editarReactivo, 
  getReactivoById, 
  getReactivos 
} from "./handlers/reactivos";
import { 
  borrarCategoria, 
  crearCategoria, 
  editarCategoria, 
  getCategoriaById, 
  getCategoriasPeligrosidad, 
  getCategoriasConCantidadReactivos 
} from "./handlers/categoriasPeligrosidad";
import { crearUsuario, login } from "./handlers/usuarios";
import { verificarToken } from "./middleware/verificarToken";

const router = Router()

// Login público
router.post('/login', login)

// Middleware para verificar token en las rutas protegidas
router.use(verificarToken)

// Reactivos
router.get('/reactivos', getReactivos)
router.get('/reactivos/:id', getReactivoById)
router.post('/reactivos', crearReactivo)
router.put('/reactivos/:id', editarReactivo)
router.delete('/reactivos/:id', borrarReactivo)

// Categorías de peligrosidad
router.get('/categorias', getCategoriasPeligrosidad)
router.get('/categorias/con-cantidad', getCategoriasConCantidadReactivos)
router.get('/categorias/:id', getCategoriaById)
router.post('/categorias', crearCategoria)
router.put('/categorias/:id', editarCategoria)
router.delete('/categorias/:id', borrarCategoria)

// Usuarios
router.post('/usuarios/crear', crearUsuario)

export default router