import { useState, useEffect } from 'react'
import { jwtDecode } from 'jwt-decode'

interface UserTokenPayload {
  idUsuario: number
  correo: string
  idRol: number
  nombreRol: string
}

interface Reactivo {
  idReactivo: number
  nombreQuimico: string
  formulaQuimica: string
  categoriaPeligrosidad: string
  stockReal: number
  unidadMedida: string
  puntoCritico: number
  estadoAlerta: 'Óptimo' | 'Bajo Reorden' | 'Crítico'
}

interface CategoriaBackend {
  idCategoria: number
  nombreCategoria: string
  pictograma?: string
}

interface ReactivoSequelize {
  idReactivo: number
  nombreQuimico: string
  formulaQuimica: string | null
  unidadMedida: string
  puntoReordenMinimo: number | string
  idCategoria: number
  cantidadDisponible: number | string
  estado: number
  categoria?: CategoriaBackend
}

interface CategoriaOption {
  idCategoria: number
  nombreCategoria: string
}

const MAPA_CATEGORIAS: Record<number, string> = {
  2: 'Inflamable',
  3: 'Comburente',
  5: 'Corrosivo',
  6: 'Tóxico',
  7: 'No Peligroso',
  8: 'Mortal',
  9: 'Atención'
}

export default function Home() {
  const [esAdmin, setEsAdmin] = useState<boolean>(false)
  const [reactivos, setReactivos] = useState<Reactivo[]>([])
  const [reactivosRaw, setReactivosRaw] = useState<ReactivoSequelize[]>([]) // <-- Declarado aquí correctamente
  const [cargando, setCargando] = useState<boolean>(true)
  const [busqueda, setBusqueda] = useState<string>('')
  const [filtroCategoria, setFiltroCategoria] = useState<string>('')
  const [categorias, setCategorias] = useState<CategoriaOption[]>([])

  // Estado para creación de reactivo
  const [nuevoReactivo, setNuevoReactivo] = useState({
    nombreQuimico: '',
    formulaQuimica: '',
    unidadMedida: 'g',
    puntoReordenMinimo: '',
    idCategoria: '',
    cantidadDisponible: ''
  })
  const [guardando, setGuardando] = useState<boolean>(false)

  // Estado para edición de reactivo
  const [reactivoEditando, setReactivoEditando] = useState<{
    idReactivo: number
    nombreQuimico: string
    formulaQuimica: string
    unidadMedida: string
    puntoReordenMinimo: number | string
    idCategoria: number | string
    cantidadDisponible: number | string
  } | null>(null)
  const [actualizando, setActualizando] = useState<boolean>(false)

  // 1. Cargar Reactivos
  const obtenerReactivos = async () => {
    try {
      const token = localStorage.getItem('token')
      const res = await fetch('http://localhost:3000/api/reactivos', {
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        }
      })

      if (!res.ok) {
        throw new Error('Error al consultar el catálogo')
      }

      const data: ReactivoSequelize[] = await res.json()
      setReactivosRaw(data)

      const reactivosAdaptados: Reactivo[] = data.map((item) => {
        const stock = parseFloat(String(item.cantidadDisponible)) || 0
        const reorden = parseFloat(String(item.puntoReordenMinimo)) || 0

        return {
          idReactivo: item.idReactivo,
          nombreQuimico: item.nombreQuimico,
          formulaQuimica: item.formulaQuimica || 'N/A',
          categoriaPeligrosidad:
            item.categoria?.nombreCategoria ||
            MAPA_CATEGORIAS[item.idCategoria] ||
            'Atención',
          stockReal: stock,
          unidadMedida: item.unidadMedida,
          puntoCritico: reorden,
          estadoAlerta: stock <= reorden ? 'Bajo Reorden' : 'Óptimo'
        }
      })

      setReactivos(reactivosAdaptados)
    } catch (error) {
      console.error('Error al cargar reactivos:', error)
    } finally {
      setCargando(false)
    }
  }

  // 2. Cargar Categorías
  const obtenerCategorias = async () => {
    try {
      const token = localStorage.getItem('token')
      const res = await fetch('http://localhost:3000/api/categorias', {
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        }
      })

      if (res.ok) {
        const data = await res.json()
        const lista = Array.isArray(data) ? data : data.data || []
        setCategorias(lista)
      }
    } catch (error) {
      console.error('Error al cargar categorías de peligrosidad:', error)
    }
  }

  // 3. Montaje inicial
  useEffect(() => {
    const token = localStorage.getItem('token')
    if (token) {
      try {
        const decoded = jwtDecode<UserTokenPayload>(token)
        setEsAdmin(decoded.idRol === 1)
      } catch (error) {
        console.error('Error al decodificar el token:', error)
      }
    }

    obtenerReactivos()
    obtenerCategorias()
  }, [])

  // 4. Crear Reactivo
  const handleCrearReactivo = async (e: React.FormEvent) => {
    e.preventDefault()
    setGuardando(true)

    try {
      const token = localStorage.getItem('token')
      const payload = {
        nombreQuimico: nuevoReactivo.nombreQuimico,
        formulaQuimica: nuevoReactivo.formulaQuimica || null,
        unidadMedida: nuevoReactivo.unidadMedida,
        puntoReordenMinimo: parseFloat(nuevoReactivo.puntoReordenMinimo) || 0,
        idCategoria: parseInt(nuevoReactivo.idCategoria),
        cantidadDisponible: parseFloat(nuevoReactivo.cantidadDisponible) || 0,
        estado: 1
      }

      const res = await fetch('http://localhost:3000/api/reactivos', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify(payload)
      })

      if (!res.ok) {
        throw new Error('Error al registrar el reactivo')
      }

      setNuevoReactivo({
        nombreQuimico: '',
        formulaQuimica: '',
        unidadMedida: 'g',
        puntoReordenMinimo: '',
        idCategoria: '',
        cantidadDisponible: ''
      })

      const modalElement = document.getElementById('modalNuevoReactivo')
      if (modalElement) {
        // @ts-ignore
        const modalInstance = window.bootstrap?.Modal?.getInstance(modalElement)
        modalInstance?.hide()
      }

      await obtenerReactivos()
    } catch (error) {
      console.error('Error al guardar:', error)
      alert('Ocurrió un error al guardar el reactivo')
    } finally {
      setGuardando(false)
    }
  }

  // 5. Preparar Edición
 const abrirModalEditar = (reactivo: ReactivoSequelize) => {
  setReactivoEditando({
    idReactivo: reactivo.idReactivo,
    nombreQuimico: reactivo.nombreQuimico,
    formulaQuimica: reactivo.formulaQuimica || '',
    unidadMedida: reactivo.unidadMedida,
    puntoReordenMinimo: reactivo.puntoReordenMinimo,
    idCategoria: reactivo.idCategoria,
    cantidadDisponible: reactivo.cantidadDisponible
  })
}

  // 6. Actualizar Reactivo (PUT)
  const handleActualizarReactivo = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!reactivoEditando) return

    setActualizando(true)

    try {
      const token = localStorage.getItem('token')
      const payload = {
        nombreQuimico: reactivoEditando.nombreQuimico,
        formulaQuimica: reactivoEditando.formulaQuimica || null,
        unidadMedida: reactivoEditando.unidadMedida,
        puntoReordenMinimo: parseFloat(String(reactivoEditando.puntoReordenMinimo)) || 0,
        idCategoria: parseInt(String(reactivoEditando.idCategoria)),
        cantidadDisponible: parseFloat(String(reactivoEditando.cantidadDisponible)) || 0
      }

      const res = await fetch(`http://localhost:3000/api/reactivos/${reactivoEditando.idReactivo}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify(payload)
      })

      if (!res.ok) {
        throw new Error('Error al actualizar el reactivo')
      }

      const modalElement = document.getElementById('modalEditarReactivo')
      if (modalElement) {
        // @ts-ignore
        const modalInstance = window.bootstrap?.Modal?.getInstance(modalElement)
        modalInstance?.hide()
      }

      setReactivoEditando(null)
      await obtenerReactivos()
    } catch (error) {
      console.error('Error al actualizar:', error)
      alert('Ocurrió un error al actualizar el reactivo')
    } finally {
      setActualizando(false)
    }
  }

  // 7. Eliminar Reactivo (Baja lógica)
  const handleEliminarReactivo = async (id: number, nombre: string) => {
    const confirmar = window.confirm(
      `¿Estás seguro de que deseas dar de baja el reactivo "${nombre}"?`
    )

    if (!confirmar) return

    try {
      const token = localStorage.getItem('token')
      const res = await fetch(`http://localhost:3000/api/reactivos/${id}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        }
      })

      if (!res.ok) {
        throw new Error('No se pudo dar de baja el reactivo')
      }

      await obtenerReactivos()
    } catch (error) {
      console.error('Error al eliminar reactivo:', error)
      alert('Ocurrió un error al intentar eliminar el reactivo.')
    }
  }

  // Filtros de búsqueda
  const reactivosFiltrados = reactivos.filter((r) => {
    const busq = busqueda.toLowerCase()
    const coincideTexto =
      r.nombreQuimico.toLowerCase().includes(busq) ||
      (r.formulaQuimica && r.formulaQuimica.toLowerCase().includes(busq))

    const coincideCategoria =
      filtroCategoria === '' || r.categoriaPeligrosidad === filtroCategoria

    return coincideTexto && coincideCategoria
  })

  // Métricas
  const totalReactivos = reactivos.length
  const stockCriticoCount = reactivos.filter(
    (r) => r.estadoAlerta === 'Bajo Reorden' || r.estadoAlerta === 'Crítico'
  ).length

  return (
    <main className="container-fluid px-4 py-4">
      {/* TARJETAS MÉTRICAS */}
      <div className="row g-3 mb-4">
        <div className="col-12 col-sm-6 col-xl-3">
          <div className="card border-0 shadow-sm rounded-3 h-100">
            <div className="card-body d-flex align-items-center">
              <div className="metric-icon bg-primary-subtle text-primary me-3 rounded-circle p-3">
                <i className="bi bi-boxes fs-3"></i>
              </div>
              <div>
                <p className="text-muted small mb-0">Total Reactivos Activos</p>
                <h4 className="fw-bold mb-0">{totalReactivos}</h4>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 col-sm-6 col-xl-3">
          <div className="card border-0 shadow-sm rounded-3 h-100">
            <div className="card-body d-flex align-items-center">
              <div className="metric-icon bg-danger-subtle text-danger me-3 rounded-circle p-3">
                <i className="bi bi-exclamation-triangle-fill fs-3"></i>
              </div>
              <div>
                <p className="text-muted small mb-0">Stock Crítico</p>
                <h4 className="fw-bold mb-0 text-danger">{stockCriticoCount}</h4>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 col-sm-6 col-xl-3">
          <div className="card border-0 shadow-sm rounded-3 h-100">
            <div className="card-body d-flex align-items-center">
              <div className="metric-icon bg-warning-subtle text-warning me-3 rounded-circle p-3">
                <i className="bi bi-calendar-x fs-3"></i>
              </div>
              <div>
                <p className="text-muted small mb-0">Lotes Próximos a Vencer (&le; 30d)</p>
                <h4 className="fw-bold mb-0 text-warning">0</h4>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 col-sm-6 col-xl-3">
          <div className="card border-0 shadow-sm rounded-3 h-100">
            <div className="card-body d-flex align-items-center">
              <div className="metric-icon bg-success-subtle text-success me-3 rounded-circle p-3">
                <i className="bi bi-mortarboard-fill fs-3"></i>
              </div>
              <div>
                <p className="text-muted small mb-0">Asignaturas Activas</p>
                <h4 className="fw-bold mb-0">4</h4>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* SECCIÓN INVENTARIO */}
      <section id="inventarioSection" className="card border-0 shadow-sm rounded-3 mb-4">
        <div className="card-header bg-white py-3 border-0 d-flex flex-wrap align-items-center justify-content-between gap-2">
          <h5 className="fw-bold mb-0">
            <i className="bi bi-flask text-primary me-2"></i>Catálogo General de Reactivos
          </h5>

          {esAdmin && (
            <div className="d-flex gap-2">
              <button
                className="btn btn-primary btn-sm"
                data-bs-toggle="modal"
                data-bs-target="#modalNuevoReactivo"
              >
                <i className="bi bi-plus-circle me-1"></i> Nuevo Reactivo
              </button>
              <button
                className="btn btn-outline-secondary btn-sm"
                data-bs-toggle="modal"
                data-bs-target="#modalDespacho"
              >
                <i className="bi bi-box-arrow-up-right me-1"></i> Registrar Salida/Despacho
              </button>
            </div>
          )}
        </div>

        <div className="card-body pt-0">
          <div className="row g-2 mb-3">
            <div className="col-md-6 col-lg-4">
              <div className="input-group input-group-sm">
                <span className="input-group-text bg-light">
                  <i className="bi bi-search"></i>
                </span>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Buscar por reactivo o fórmula..."
                  value={busqueda}
                  onChange={(e) => setBusqueda(e.target.value)}
                />
              </div>
            </div>
            <div className="col-md-4 col-lg-3">
              <select
                className="form-select form-select-sm"
                value={filtroCategoria}
                onChange={(e) => setFiltroCategoria(e.target.value)}
              >
                <option value="">Todas las categorías</option>
                {categorias.map((cat) => (
                  <option key={cat.idCategoria} value={cat.nombreCategoria}>
                    {cat.nombreCategoria}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="table-responsive">
            <table className="table table-hover align-middle mb-0">
              <thead className="table-light">
                <tr className="small text-muted text-uppercase">
                  <th>Cód.</th>
                  <th>Nombre Químico</th>
                  <th>Fórmula</th>
                  <th>Peligrosidad</th>
                  <th>Stock Real</th>
                  <th>Pto. Crítico</th>
                  <th>Estado Alerta</th>
                  {esAdmin && <th className="text-end">Acciones</th>}
                </tr>
              </thead>
              <tbody>
                {cargando ? (
                  <tr>
                    <td colSpan={esAdmin ? 8 : 7} className="text-center py-4 text-muted">
                      <div className="spinner-border spinner-border-sm me-2" role="status"></div>
                      Cargando reactivos de la bodega...
                    </td>
                  </tr>
                ) : reactivosFiltrados.length === 0 ? (
                  <tr>
                    <td colSpan={esAdmin ? 8 : 7} className="text-center py-4 text-muted">
                      No se encontraron reactivos registrados
                    </td>
                  </tr>
                ) : (
                  reactivosFiltrados.map((item) => (
                    <tr key={item.idReactivo}>
                      <td>{item.idReactivo}</td>
                      <td className="fw-semibold">{item.nombreQuimico}</td>
                      <td><code>{item.formulaQuimica}</code></td>
                      <td>
                        <span className="badge bg-dark">{item.categoriaPeligrosidad}</span>
                      </td>
                      <td>{`${item.stockReal} ${item.unidadMedida}`}</td>
                      <td>{`${item.puntoCritico} ${item.unidadMedida}`}</td>
                      <td>
                        <span
                          className={`badge ${
                            item.estadoAlerta === 'Óptimo' ? 'bg-success' : 'bg-danger'
                          }`}
                        >
                          {item.estadoAlerta}
                        </span>
                      </td>

                      {esAdmin && (
                        <td className="text-end">
                          <button
                            className="btn btn-outline-primary btn-sm border-0 me-1"
                            title="Modificar reactivo"
                            data-bs-toggle="modal"
                            data-bs-target="#modalEditarReactivo"
                            onClick={() => {
                              const itemOriginal = reactivosRaw.find(
                                (r) => r.idReactivo === item.idReactivo
                              )
                              if (itemOriginal) abrirModalEditar(itemOriginal)
                            }}
                          >
                            <i className="bi bi-pencil"></i>
                          </button>
                          <button
                            className="btn btn-outline-danger btn-sm border-0"
                            title="Dar de baja reactivo"
                            onClick={() =>
                              handleEliminarReactivo(item.idReactivo, item.nombreQuimico)
                            }
                          >
                            <i className="bi bi-trash"></i>
                          </button>
                        </td>
                      )}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* MODAL NUEVO REACTIVO */}
      <div className="modal fade" id="modalNuevoReactivo" tabIndex={-1} aria-hidden="true">
        <div className="modal-dialog modal-lg">
          <div className="modal-content border-0 shadow">
            <div className="modal-header bg-primary text-white">
              <h6 className="modal-title fw-semibold">
                <i className="bi bi-plus-circle me-1"></i> Registrar Reactivo Químico
              </h6>
              <button type="button" className="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>

            <form onSubmit={handleCrearReactivo}>
              <div className="modal-body row g-3">
                <div className="col-md-7">
                  <label className="form-label small fw-semibold">Nombre Químico</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Ej: Sulfato de Cobre"
                    value={nuevoReactivo.nombreQuimico}
                    onChange={(e) =>
                      setNuevoReactivo({ ...nuevoReactivo, nombreQuimico: e.target.value })
                    }
                    required
                  />
                </div>

                <div className="col-md-5">
                  <label className="form-label small fw-semibold">Fórmula Molecular</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Ej: CuSO4"
                    value={nuevoReactivo.formulaQuimica}
                    onChange={(e) =>
                      setNuevoReactivo({ ...nuevoReactivo, formulaQuimica: e.target.value })
                    }
                  />
                </div>

                <div className="col-md-4">
                  <label className="form-label small fw-semibold">Unidad de Medida</label>
                  <select
                    className="form-select"
                    value={nuevoReactivo.unidadMedida}
                    onChange={(e) =>
                      setNuevoReactivo({ ...nuevoReactivo, unidadMedida: e.target.value })
                    }
                    required
                  >
                    <option value="g">Gramos (g)</option>
                    <option value="kg">Kilogramos (kg)</option>
                    <option value="mL">Mililitros (mL)</option>
                    <option value="L">Litros (L)</option>
                    <option value="unidad">Unidad</option>
                  </select>
                </div>

                <div className="col-md-4">
                  <label className="form-label small fw-semibold">Categoría de Peligrosidad</label>
                  <select
                    className="form-select"
                    value={nuevoReactivo.idCategoria}
                    onChange={(e) =>
                      setNuevoReactivo({ ...nuevoReactivo, idCategoria: e.target.value })
                    }
                    required
                  >
                    <option value="">Seleccione categoría...</option>
                    {categorias.map((cat) => (
                      <option key={cat.idCategoria} value={cat.idCategoria}>
                        {cat.nombreCategoria}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="col-md-4">
                  <label className="form-label small fw-semibold">Punto de Reorden Mínimo</label>
                  <input
                    type="number"
                    step="0.01"
                    className="form-control"
                    placeholder="Ej: 50.00"
                    value={nuevoReactivo.puntoReordenMinimo}
                    onChange={(e) =>
                      setNuevoReactivo({ ...nuevoReactivo, puntoReordenMinimo: e.target.value })
                    }
                    required
                  />
                </div>

                <div className="col-md-6">
                  <label className="form-label small fw-semibold">Cantidad Inicial (Stock Físico)</label>
                  <input
                    type="number"
                    step="0.01"
                    className="form-control"
                    placeholder="Ej: 500"
                    value={nuevoReactivo.cantidadDisponible}
                    onChange={(e) =>
                      setNuevoReactivo({ ...nuevoReactivo, cantidadDisponible: e.target.value })
                    }
                    required
                  />
                </div>
              </div>

              <div className="modal-footer bg-light">
                <button type="button" className="btn btn-secondary btn-sm" data-bs-dismiss="modal">
                  Cancelar
                </button>
                <button type="submit" className="btn btn-primary btn-sm" disabled={guardando}>
                  {guardando ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-1" role="status"></span>
                      Guardando...
                    </>
                  ) : (
                    <>
                      <i className="bi bi-save me-1"></i> Guardar Reactivo
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      {/* MODAL EDITAR REACTIVO */}
      <div className="modal fade" id="modalEditarReactivo" tabIndex={-1} aria-hidden="true">
        <div className="modal-dialog modal-lg">
          <div className="modal-content border-0 shadow">
            <div className="modal-header bg-warning-subtle text-dark">
              <h6 className="modal-title fw-semibold">
                <i className="bi bi-pencil-square me-1"></i> Modificar Reactivo Químico
              </h6>
              <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
            </div>

            {reactivoEditando && (
              <form onSubmit={handleActualizarReactivo}>
                <div className="modal-body row g-3">
                  <div className="col-md-7">
                    <label className="form-label small fw-semibold">Nombre Químico</label>
                    <input
                      type="text"
                      className="form-control"
                      value={reactivoEditando.nombreQuimico}
                      onChange={(e) =>
                        setReactivoEditando({
                          ...reactivoEditando,
                          nombreQuimico: e.target.value
                        })
                      }
                      required
                    />
                  </div>

                  <div className="col-md-5">
                    <label className="form-label small fw-semibold">Fórmula Molecular</label>
                    <input
                      type="text"
                      className="form-control"
                      value={reactivoEditando.formulaQuimica}
                      onChange={(e) =>
                        setReactivoEditando({
                          ...reactivoEditando,
                          formulaQuimica: e.target.value
                        })
                      }
                    />
                  </div>

                  <div className="col-md-4">
                    <label className="form-label small fw-semibold">Unidad de Medida</label>
                    <select
                      className="form-select"
                      value={reactivoEditando.unidadMedida}
                      onChange={(e) =>
                        setReactivoEditando({
                          ...reactivoEditando,
                          unidadMedida: e.target.value
                        })
                      }
                      required
                    >
                      <option value="g">Gramos (g)</option>
                      <option value="kg">Kilogramos (kg)</option>
                      <option value="mL">Mililitros (mL)</option>
                      <option value="L">Litros (L)</option>
                      <option value="unidad">Unidad</option>
                    </select>
                  </div>

                  <div className="col-md-4">
                    <label className="form-label small fw-semibold">Categoría de Peligrosidad</label>
                    <select
                      className="form-select"
                      value={reactivoEditando.idCategoria}
                      onChange={(e) =>
                        setReactivoEditando({
                          ...reactivoEditando,
                          idCategoria: e.target.value
                        })
                      }
                      required
                    >
                      <option value="">Seleccione categoría...</option>
                      {categorias.map((cat) => (
                        <option key={cat.idCategoria} value={cat.idCategoria}>
                          {cat.nombreCategoria}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="col-md-4">
                    <label className="form-label small fw-semibold">Punto de Reorden Mínimo</label>
                    <input
                      type="number"
                      step="0.01"
                      className="form-control"
                      value={reactivoEditando.puntoReordenMinimo}
                      onChange={(e) =>
                        setReactivoEditando({
                          ...reactivoEditando,
                          puntoReordenMinimo: e.target.value
                        })
                      }
                      required
                    />
                  </div>

                  <div className="col-md-6">
                    <label className="form-label small fw-semibold">Stock Físico Actual</label>
                    <input
                      type="number"
                      step="0.01"
                      className="form-control"
                      value={reactivoEditando.cantidadDisponible}
                      onChange={(e) =>
                        setReactivoEditando({
                          ...reactivoEditando,
                          cantidadDisponible: e.target.value
                        })
                      }
                      required
                    />
                  </div>
                </div>

                <div className="modal-footer bg-light">
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    data-bs-dismiss="modal"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="btn btn-warning btn-sm"
                    disabled={actualizando}
                  >
                    {actualizando ? (
                      <>
                        <span
                          className="spinner-border spinner-border-sm me-1"
                          role="status"
                        ></span>
                        Guardando cambios...
                      </>
                    ) : (
                      <>
                        <i className="bi bi-check-lg me-1"></i> Actualizar Reactivo
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </main>
  )
}